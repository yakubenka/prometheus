"""
Prometheus — Signal Engine v5.0
Decision engine стал более датовым и экономным по AI:

- сначала считаем не-AI сигналы
- AI вызывается редко и только как sanity check
- итоговый вход требует quality score и внешнее подтверждение
"""
from __future__ import annotations
import json
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional, TYPE_CHECKING

import requests
from anthropic import Anthropic

from config import cfg
from data import Market, fetch_market_price_history

if TYPE_CHECKING:
    from intel import IntelPipeline

log = logging.getLogger("prometheus.signals")

_S = requests.Session()
_S.headers["User-Agent"] = "Prometheus/5.0"

_MODEL_FAST = "claude-haiku-4-5-20251001"

_DOMAIN_MIN_EDGE = {
    "crypto":      0.10,
    "sports":      0.08,
    "macro":       0.06,
    "politics":    0.04,
    "geopolitics": 0.05,
    "tech":        0.06,
    "other":       0.05,
}

_CONF_KELLY = {
    "high":   1.00,
    "medium": 0.70,
    "low":    0.40,
}

_AI_SIGNAL_NAMES = {"ai_guard", "sentiment", "calibration", "base_rate"}
_NON_AI_SIGNAL_NAMES = {"momentum", "consensus", "predictit", "volume_spike"}


def get_domain_min_edge(tags: list, default: float = 0.05) -> float:
    for tag in (tags or []):
        t = str(tag).lower()
        if t in _DOMAIN_MIN_EDGE:
            return _DOMAIN_MIN_EDGE[t]
    return default


def get_confidence_kelly_mult(confidence: str) -> float:
    return _CONF_KELLY.get(confidence, 0.50)


@dataclass
class Signal:
    name:       str
    score:      float
    confidence: float
    direction:  str
    reasoning:  str
    weight:     float = 0.0


@dataclass
class EnsembleResult:
    final_score:    float
    direction:      str
    edge:           float
    ai_probability: float
    confidence:     str
    signals:        list[Signal] = field(default_factory=list)
    reasoning:      str = ""
    question_type:  str = "general"
    trade_quality:  int = 0
    strategy_type:  str = "market_data"
    ai_used:        bool = False
    ai_calls_used:  int = 0


def _parse_ai_json(text: str) -> dict:
    clean = text.strip().replace("```json", "").replace("```", "").strip()
    return json.loads(clean)


def _classify_question(question: str) -> str:
    q = (question or "").lower()
    if any(w in q for w in ["election", "vote", "president", "senator", "congress", "poll"]):
        return "electoral"
    if any(w in q for w in ["fed", "rate", "inflation", "gdp", "cpi", "recession", "market"]):
        return "economic"
    if any(w in q for w in ["war", "attack", "iran", "russia", "china", "ukraine", "military", "nato"]):
        return "geopolitical"
    if any(w in q for w in ["bitcoin", "btc", "eth", "crypto", "solana"]):
        return "crypto"
    if any(w in q for w in ["will", "reach", "exceed", "above", "below", "by"]):
        return "binary"
    return "general"


def _build_market_snapshot(market: Market, intel=None) -> str:
    parts = [
        f"Market: {market.question}",
        f"Current yes price: {market.yes_price:.3f}",
        f"24h volume: ${market.volume_24h:,.0f}",
    ]
    if market.description:
        parts.append(f"Resolution rules: {market.description[:300]}")
    if market.end_date:
        try:
            end = datetime.fromisoformat(market.end_date.replace("Z", "+00:00"))
            days_left = max(0.0, (end - datetime.now(timezone.utc)).total_seconds() / 86400)
            parts.append(f"Days left: {days_left:.1f}")
        except Exception:
            pass
    if intel:
        try:
            news = intel.context_for(market.question, hours=24)
            if news and "No recent" not in news:
                parts.append(f"Recent news:\n{news[:500]}")
        except Exception:
            pass
    return "\n".join(parts)


def _detect_volume_anomaly(market: Market) -> Optional[Signal]:
    try:
        r = _S.get("https://gamma-api.polymarket.com/markets", params={"id": market.id}, timeout=5)
        if r.status_code != 200:
            return None
        data = r.json()
        items = data if isinstance(data, list) else data.get("data", [data])
        if not items:
            return None
        m = items[0] if isinstance(items, list) else items
        vol_1h = float(m.get("volume1hr", 0) or 0)
        vol_24h = float(m.get("volume24hr", 0) or market.volume_24h or 0)
        if vol_1h <= 0 or vol_24h <= 0:
            return None
        expected_1h = vol_24h / 24
        if expected_1h <= 0:
            return None
        spike = vol_1h / expected_1h
        if spike >= 6.0:
            return Signal("volume_spike", market.yes_price, 0.70, "NEUTRAL", f"Volume spike {spike:.1f}x")
        if spike >= 3.5:
            return Signal("volume_spike", market.yes_price, 0.45, "NEUTRAL", f"Volume elevated {spike:.1f}x")
        return None
    except Exception as e:
        log.debug(f"Volume anomaly error: {e}")
        return None


class SignalEngine:
    DEFAULT_WEIGHTS = {
        "momentum":     0.20,
        "consensus":    0.34,
        "predictit":    0.24,
        "volume_spike": 0.08,
        "ai_guard":     0.14,
        "sentiment":    0.06,
        "calibration":  0.04,
        "base_rate":    0.04,
    }

    def __init__(self, ai: Optional[Anthropic], intel: Optional["IntelPipeline"] = None) -> None:
        self.ai = ai
        self.intel = intel
        self.weights = dict(self.DEFAULT_WEIGHTS)
        self._ai_budget_remaining = cfg.ai_request_budget_per_cycle

    def reset_cycle_budget(self) -> None:
        self._ai_budget_remaining = cfg.ai_request_budget_per_cycle

    def analyze(self, market: Market, pre_score: float = 0.0) -> EnsembleResult:
        question_type = _classify_question(market.question)
        signals = self._run_non_ai_parallel(market)
        initial = self._ensemble(market, signals)
        quality = self._trade_quality(market, initial, signals, pre_score)
        strategy = self._strategy_type(initial.direction, signals, ai_used=False)

        ai_signal = None
        if self._should_call_ai(initial, quality, signals):
            ai_signal = self._ai_guard(market)
            if ai_signal:
                ai_signal.weight = self.weights.get("ai_guard", 0.14)
                signals.append(ai_signal)
                self._ai_budget_remaining = max(0, self._ai_budget_remaining - 1)

        result = self._ensemble(market, signals)
        result.question_type = question_type
        result.trade_quality = self._trade_quality(market, result, signals, pre_score)
        result.strategy_type = self._strategy_type(result.direction, signals, ai_used=ai_signal is not None)
        result.ai_used = ai_signal is not None
        result.ai_calls_used = 1 if ai_signal is not None else 0

        tradeability = self._tradeability_score(market, signals, pre_score)
        min_edge = max(get_domain_min_edge(list(market.tags), cfg.min_edge), cfg.min_edge)
        external_support = self._external_support_count(result.direction, signals)
        market_data_support = self._market_data_support_count(result.direction, signals)

        if tradeability < 45:
            result.direction = "NEUTRAL"
            result.confidence = "low"
            result.reasoning = f"tradeability={tradeability} too low"
        elif result.trade_quality < cfg.min_trade_quality:
            result.direction = "NEUTRAL"
            result.confidence = "low"
            result.reasoning = f"quality={result.trade_quality} below threshold"
        elif result.strategy_type == "ai_assisted" and result.edge < max(cfg.ai_unconfirmed_edge, min_edge):
            result.direction = "NEUTRAL"
            result.confidence = "low"
            result.reasoning = "AI-assisted setup without enough edge"
        elif result.direction != "NEUTRAL" and external_support == 0 and market_data_support < 2 and result.edge < (min_edge * 1.5):
            result.direction = "NEUTRAL"
            result.confidence = "low"
            result.reasoning = "Not enough non-AI confirmation"

        return result

    def _run_non_ai_parallel(self, market: Market) -> list[Signal]:
        tasks = {
            "momentum": lambda: self._momentum(market),
            "consensus": lambda: self._consensus(market),
            "predictit": lambda: self._predictit(market),
            "volume_spike": lambda: _detect_volume_anomaly(market) or Signal("volume_spike", market.yes_price, 0.10, "NEUTRAL", "no anomaly"),
        }
        results: dict[str, Signal] = {}
        with ThreadPoolExecutor(max_workers=4) as executor:
            futures = {executor.submit(fn): name for name, fn in tasks.items()}
            for future in as_completed(futures, timeout=20):
                name = futures[future]
                try:
                    results[name] = future.result()
                except Exception as e:
                    log.debug(f"Signal {name} failed: {e}")
                    results[name] = Signal(name, market.yes_price, 0.10, "NEUTRAL", "error")
        out = []
        for name in tasks:
            sig = results.get(name, Signal(name, market.yes_price, 0.10, "NEUTRAL", "error"))
            sig.weight = self.weights.get(sig.name, 0.05)
            out.append(sig)
        return out

    def _momentum(self, market: Market) -> Signal:
        try:
            history = fetch_market_price_history(market.id, days=3)
            prices = [float(p["p"]) for p in history if p.get("p")]
            if len(prices) < 6:
                return Signal("momentum", market.yes_price, 0.2, "NEUTRAL", "insufficient history")
            cur = prices[-1]
            d24 = prices[max(0, len(prices) - 24)]
            d72 = prices[0]
            m24 = cur - d24
            m72 = cur - d72
            if m24 > 0.08 and m72 > 0.10:
                return Signal("momentum", min(0.90, cur + m24 * 0.20), 0.60, "YES", f"up {m24:.1%}/24h")
            if m24 < -0.08 and m72 < -0.10:
                return Signal("momentum", max(0.10, cur + m24 * 0.20), 0.60, "NO", f"down {abs(m24):.1%}/24h")
            return Signal("momentum", cur, 0.25, "NEUTRAL", f"flat {m24:+.1%}/24h")
        except Exception as e:
            log.debug(f"Momentum error: {e}")
            return Signal("momentum", market.yes_price, 0.15, "NEUTRAL", "error")

    def _consensus(self, market: Market) -> Signal:
        kalshi = self._kalshi_price(market.question)
        if kalshi is None:
            return Signal("consensus", market.yes_price, 0.10, "NEUTRAL", "no Kalshi match")
        spread = market.yes_price - kalshi
        if abs(spread) < 0.02:
            return Signal("consensus", (market.yes_price + kalshi) / 2, 0.60, "NEUTRAL", f"PM≈Kalshi {spread:+.1%}")
        if spread > 0:
            return Signal("consensus", kalshi, min(0.90, abs(spread) * 9), "NO", f"PM rich vs Kalshi by {spread:.1%}")
        return Signal("consensus", kalshi, min(0.90, abs(spread) * 9), "YES", f"PM cheap vs Kalshi by {abs(spread):.1%}")

    def _predictit(self, market: Market) -> Signal:
        try:
            from predictit import arbitrage_signal
            result = arbitrage_signal(market.question, market.yes_price)
            if result is None:
                return Signal("predictit", market.yes_price, 0.10, "NEUTRAL", "no PredictIt match")
            if result["signal"] == "NEUTRAL":
                return Signal("predictit", result["pi_price"], 0.35, "NEUTRAL", result["reasoning"])
            conf = min(0.85, abs(result["gap"]) * 8)
            return Signal("predictit", result["pi_price"], conf, result["signal"], result["reasoning"])
        except Exception as e:
            log.debug(f"PredictIt error: {e}")
            return Signal("predictit", market.yes_price, 0.10, "NEUTRAL", "error")

    def _ai_guard(self, market: Market) -> Optional[Signal]:
        if cfg.ai_mode == "off" or not self.ai or self._ai_budget_remaining <= 0:
            return None
        snapshot = _build_market_snapshot(market, self.intel)
        prompt = (
            f"{snapshot}\n\n"
            "Decide if this market is TRADEABLE at all.\n"
            "Focus only on: resolution ambiguity, obvious missing context, and whether the current market price looks clearly wrong.\n"
            "Do NOT invent precise certainty.\n"
            'Return ONLY JSON: {"tradable":true,"probability":0.0,"confidence":"low|medium|high","risk_flag":"none|ambiguous_rules|missing_context|news_unclear","reasoning":"max 80 chars"}'
        )
        try:
            resp = self._raw_ai_call(prompt, max_tokens=120, model=_MODEL_FAST)
            data = _parse_ai_json(resp)
            tradable = bool(data.get("tradable", False))
            prob = float(data.get("probability", market.yes_price))
            conf = {"low": 0.30, "medium": 0.55, "high": 0.72}.get(data.get("confidence", "low"), 0.30)
            risk_flag = data.get("risk_flag", "none")
            reasoning = data.get("reasoning", "") or risk_flag
            diff = prob - market.yes_price
            if not tradable or risk_flag in {"ambiguous_rules", "missing_context"}:
                return Signal("ai_guard", market.yes_price, 0.80, "NEUTRAL", f"AI veto: {risk_flag}")
            direction = "YES" if diff > 0.04 else "NO" if diff < -0.04 else "NEUTRAL"
            return Signal("ai_guard", prob, conf, direction, reasoning[:120])
        except Exception as e:
            log.debug(f"AI guard error: {e}")
            return None

    def _should_call_ai(self, result: EnsembleResult, quality: int, signals: list[Signal]) -> bool:
        if cfg.ai_mode == "off" or not self.ai or self._ai_budget_remaining <= 0:
            return False
        if cfg.ai_mode == "full":
            return True
        if quality < max(cfg.ai_min_quality_for_call, 58):
            return False
        if quality >= cfg.ai_high_quality_skip and self._external_support_count(result.direction, signals) >= 1:
            return False
        if result.direction == "NEUTRAL":
            return quality >= cfg.ai_min_quality_for_call + 12
        return self._external_support_count(result.direction, signals) == 0 and quality >= cfg.ai_min_quality_for_call + 8

    def _tradeability_score(self, market: Market, signals: list[Signal], pre_score: float) -> int:
        score = 0.0
        if market.volume_24h >= cfg.min_volume * 2:
            score += 28.0
        elif market.volume_24h >= cfg.min_volume:
            score += 20.0
        elif market.volume_24h >= cfg.min_volume * 0.5:
            score += 8.0
        else:
            score -= 28.0
        if hasattr(market, "spread") and market.spread <= 0.02:
            score += 18.0
        elif hasattr(market, "spread") and market.spread <= 0.04:
            score += 10.0
        else:
            score -= 8.0
        if market.description and len(market.description) >= 60:
            score += 8.0
        else:
            score -= 4.0
        if getattr(market, "market_url", None) or getattr(market, "event_url", None):
            score += 6.0
        else:
            score -= 4.0
        if 0.03 <= market.yes_price <= 0.97:
            score += 8.0
        if 0.08 <= market.yes_price <= 0.92:
            score += 6.0
        score += min(12.0, max(0.0, pre_score) * 10.0)
        vol = next((s for s in signals if s.name == "volume_spike" and s.confidence >= 0.45), None)
        if vol:
            score += 4.0
        return int(max(0, min(100, round(score))))

    def _trade_quality(self, market: Market, result: EnsembleResult, signals: list[Signal], pre_score: float) -> int:
        score = self._tradeability_score(market, signals, pre_score) * 0.45
        score += min(30.0, result.edge * 180.0)
        score += min(8.0, max(0.0, pre_score) * 8.0)

        ext_support = self._external_support_count(result.direction, signals)
        market_data_support = self._market_data_support_count(result.direction, signals)
        if ext_support >= 2:
            score += 22.0
        elif ext_support == 1:
            score += 12.0
        if market_data_support >= 2:
            score += 10.0
        elif market_data_support == 1:
            score += 4.0

        momentum = next((s for s in signals if s.name == "momentum" and s.direction == result.direction), None)
        if momentum:
            score += 6.0

        vol = next((s for s in signals if s.name == "volume_spike" and s.confidence >= 0.45), None)
        if vol:
            score += 4.0

        if result.direction == "NEUTRAL":
            score -= 20.0
        if result.direction != "NEUTRAL" and self._external_support_count(result.direction, signals) == 0:
            score -= 10.0
        if result.direction != "NEUTRAL" and self._market_data_support_count(result.direction, signals) == 0:
            score -= 8.0
        if result.confidence == "low":
            score -= 6.0
        if result.edge < max(cfg.min_edge, get_domain_min_edge(list(market.tags), cfg.min_edge)):
            score -= 6.0

        return int(max(0, min(100, round(score))))

    def _external_support_count(self, direction: str, signals: list[Signal]) -> int:
        if direction == "NEUTRAL":
            return 0
        return sum(
            1 for s in signals
            if s.name in {"consensus", "predictit"} and s.direction == direction and s.confidence >= 0.35
        )

    def _market_data_support_count(self, direction: str, signals: list[Signal]) -> int:
        if direction == "NEUTRAL":
            return 0
        return sum(
            1 for s in signals
            if s.name in _NON_AI_SIGNAL_NAMES and s.direction == direction and s.confidence >= 0.35
        )

    def _strategy_type(self, direction: str, signals: list[Signal], ai_used: bool) -> str:
        if direction != "NEUTRAL" and self._external_support_count(direction, signals) >= 1:
            return "cross_market_gap"
        if ai_used:
            return "ai_assisted"
        return "market_data"

    def _ensemble(self, market: Market, signals: list[Signal]) -> EnsembleResult:
        no_data = {"no Kalshi match", "no PredictIt match", "error", "insufficient history", "no anomaly"}
        active = [s for s in signals if not (s.direction == "NEUTRAL" and s.reasoning in no_data)]
        if not active:
            active = signals

        total_w = sum(max(0.01, s.weight) * max(0.05, s.confidence) for s in active)
        if total_w <= 0:
            return EnsembleResult(0.5, "NEUTRAL", 0.0, 0.5, "low", signals)

        prob = sum(s.score * max(0.01, s.weight) * max(0.05, s.confidence) for s in active) / total_w
        edge = abs(prob - market.yes_price)
        yes_w = sum(s.weight * s.confidence for s in active if s.direction == "YES")
        no_w = sum(s.weight * s.confidence for s in active if s.direction == "NO")

        if prob > market.yes_price + 0.02 and yes_w > no_w:
            direction = "YES"
        elif prob < market.yes_price - 0.02 and no_w > yes_w:
            direction = "NO"
        else:
            direction = "NEUTRAL"

        external_support = self._external_support_count(direction, active)
        non_ai_support = [s for s in active if s.name in _NON_AI_SIGNAL_NAMES and s.direction == direction]
        ai_only = direction != "NEUTRAL" and not non_ai_support
        if ai_only:
            return EnsembleResult(round(prob, 4), "NEUTRAL", round(edge, 4), round(prob, 4), "low", signals, "ai-only setup")

        avg_conf = sum(s.confidence for s in active) / max(len(active), 1)
        vote_margin = abs(yes_w - no_w) / max(total_w, 0.01)
        if edge >= 0.12 and external_support >= 1 and vote_margin > 0.20:
            conf = "high"
        elif edge >= 0.05 and (external_support >= 1 or avg_conf >= 0.45):
            conf = "medium"
        else:
            conf = "low"

        top3 = sorted(active, key=lambda s: s.confidence * max(0.01, s.weight), reverse=True)[:3]
        reasoning = " · ".join(
            f"[{s.name}] {s.reasoning[:70]}"
            for s in top3
            if s.reasoning and s.reasoning not in no_data
        )

        return EnsembleResult(
            final_score=round(prob, 4),
            direction=direction,
            edge=round(edge, 4),
            ai_probability=round(prob, 4),
            confidence=conf,
            signals=signals,
            reasoning=reasoning,
        )

    def update_weights(self, performance: dict) -> None:
        total = sum(max(0.01, v) for v in performance.values())
        for name, acc in performance.items():
            if name in self.weights:
                self.weights[name] = round(max(0.03, acc / total), 3)

    def _raw_ai_call(self, prompt: str, *, max_tokens: int = 150, model: str = _MODEL_FAST) -> str:
        if not self.ai:
            raise RuntimeError("AI disabled")
        msg = self.ai.messages.create(
            model=model,
            max_tokens=max_tokens,
            messages=[{"role": "user", "content": prompt}],
        )
        return msg.content[0].text.strip()

    def _kalshi_price(self, question: str) -> Optional[float]:
        try:
            r = _S.get("https://trading-api.kalshi.com/trade-api/v2/markets", timeout=5)
            if r.status_code != 200:
                return None
            data = r.json().get("markets", [])
            q_words = [w for w in question.lower().split() if len(w) > 3][:6]
            best = None
            best_score = 0
            for m in data[:500]:
                title = (m.get("title") or "").lower()
                score = sum(1 for w in q_words if w in title)
                if score > best_score:
                    best_score = score
                    best = m
            if not best or best_score < 2:
                return None
            yes_bid = best.get("yes_bid")
            yes_ask = best.get("yes_ask")
            if yes_bid is None and yes_ask is None:
                return None
            vals = [v / 100 for v in [yes_bid, yes_ask] if isinstance(v, (int, float))]
            if not vals:
                return None
            return sum(vals) / len(vals)
        except Exception as e:
            log.debug(f"Kalshi fetch error: {e}")
            return None
